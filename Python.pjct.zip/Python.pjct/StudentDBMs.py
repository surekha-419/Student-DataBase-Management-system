import json
FILENAME = "student.json"

def load_students():
    try:
        with open(FILENAME,"r") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return[]
    
def add_students(students):
    sid = input("Enter student ID: ")
    name = input("Enter Name: ")
    age = input("Enter Age: ")
    course = input("Enter Course: ")
    marks = input("Enter Marks: ")   
    students.append({
        "id": sid,
        "name": name,
        "age": age,
        "course": course,
        "marks": marks
    }) 
    print("Student added succesfully")
    
def display_Students(students):
    if not students:
        print("No students records found")
        return   
    print("\---- STUDENTS RECORDS ----")
    for s in students:
        print(f"ID:{s["id"]} Name: {s["name"]}, Age: {s["age"]}, Course: {s["course"]}, Marks: {s["marks"]}")
        
def search_students(students):
    sid=input("Enter Students ID to search: ")
    
    for s in students:
        if s["id"] == sid:
            print(f"Found -> {s}")
            return
    print("Student REcord Not Found") 
    
def update_students(students):
    sid=input("Enter Students ID to update: ")
    
    for s in students:
        if s["id"] == sid:
            s["name"] = input("Enter New Name: ")
            s["age"] = input("Enter New Age: ")
            s["course"] = input("Enter New Course: ")
            s["marks"] = input("Enter New Marks: ")
             
            print("Student Updated Succesfully")
            return
        print(" Student Not Found")
        
def delete_students(students):
    sid=input("Enter Students ID to delete: ")
    
    for s in students:
        
        if s["id"] == sid:
            students.remove(s)
            print(f"Student deleted succesfully")
            return
    print("Student REcord Not Found") 
             
def save_students(students):
    with open(FILENAME,"w") as f:
        json.dump(students,f,indent=4)  
        
def main(): 
    
    students=load_students()
  
    while True:
        print("\n===StudentDB Menu===")
        print("1.Add Student")
        print("2.Displays Students")
        print("3.Search Students")
        print("4.Update Students")
        print("5.Delete Students")
        print("6.save & Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            add_students(students)
        elif choice == "2":
            display_Students(students)
        elif choice == "3":
            search_students(students)
        elif choice == "4":
            update_students(students)
        elif choice == "5":
            delete_students(students)
        elif choice == "6":
            save_students(students)
            print("Data saved. Existing program")
            break
        else:
            print("Invalid choice! try again")
            
main()